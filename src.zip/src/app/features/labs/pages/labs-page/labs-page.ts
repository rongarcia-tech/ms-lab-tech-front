import { Component } from '@angular/core';

@Component({
  selector: 'app-labs-page',
  templateUrl: './labs-page.html',
  styleUrl: './labs-page.scss',
})
export class LabsPage {

}
