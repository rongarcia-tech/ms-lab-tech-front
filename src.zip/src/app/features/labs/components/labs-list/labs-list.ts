import { Component } from '@angular/core';

@Component({
  selector: 'app-labs-list',
  templateUrl: './labs-list.html',
  styleUrl: './labs-list.scss',
})
export class LabsList {

}
